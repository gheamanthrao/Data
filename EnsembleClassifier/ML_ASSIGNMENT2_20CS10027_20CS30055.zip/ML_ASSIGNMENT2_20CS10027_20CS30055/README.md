# How to run the code

1. Download the supervised and unsupervised folders and open in pycharm seperately 

2. No need to install the data file as i have included in the folder itself, import all the packages mentioned in the main.py of both the folders and run the main.

3. The results get printed in the terminal and the diagrams will be available in the folder.


